package com.example.laborator3_app;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button nextButton, prevButton, detailsButton;
    private ImageFragment imageFragment;
    private int currentIndex = 0;

    private int[] images = {R.drawable.image1, R.drawable.image2, R.drawable.image3}; // 3 imagini
    private String[] descriptions = {"Descriere 1", "Descriere 2", "Descriere 3"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nextButton = findViewById(R.id.btn_next);
        prevButton = findViewById(R.id.btn_prev);
        detailsButton = findViewById(R.id.btn_details);

        imageFragment = (ImageFragment) getSupportFragmentManager().findFragmentById(R.id.fragment_image);

        updateFragment();

        nextButton.setOnClickListener(v -> {
            currentIndex = (currentIndex + 1) % images.length;
            updateFragment();
        });

        prevButton.setOnClickListener(v -> {
            currentIndex = (currentIndex - 1 + images.length) % images.length;
            updateFragment();
        });

        detailsButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, DetailsActivity.class);
            intent.putExtra("description", descriptions[currentIndex]);
            startActivity(intent);
        });
    }

    private void updateFragment() {
        imageFragment.updateContent(images[currentIndex], descriptions[currentIndex]);
    }
}
