package com.example.laborator3_app;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;

public class DetailsActivity extends AppCompatActivity {

    private EditText descriptionEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        descriptionEditText = findViewById(R.id.edit_text_description);

        String description = getIntent().getStringExtra("description");
        if (description != null) {
            descriptionEditText.setText(description);
        }
    }
}