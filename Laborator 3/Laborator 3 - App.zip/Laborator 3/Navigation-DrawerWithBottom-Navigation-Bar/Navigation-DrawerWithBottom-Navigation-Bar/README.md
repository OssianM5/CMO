# Navigation-DrawerWithBottom-Navigation-Bar
Navigation Drawer + Bottom Navigation in Android Studio Kotlin

# [YouTube Video Link](https://youtu.be/VL_ccRojUTI)

![Navigation Drawer with Bottom Navigation App](screenshot/img1.png)


## Support the Project

If you find this tutorial series helpful and would like to support the development of more content, consider buying me a coffee! Your support helps in creating high-quality tutorials.

[![Buy Me a Coffee](https://img.shields.io/badge/Buy%20Me%20a%20Coffee-Donate-orange?style=for-the-badge&logo=buy-me-a-coffee)](https://www.buymeacoffee.com/codingmeet)

Your generosity is greatly appreciated! Thank you for supporting this project.

