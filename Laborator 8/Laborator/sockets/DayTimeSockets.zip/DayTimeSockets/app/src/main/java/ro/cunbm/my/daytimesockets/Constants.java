package ro.cunbm.my.daytimesockets;

/**
 * @author CCE
 *
 */
public class Constants {

    public final static String NIST_SERVER_HOST = "utcnist.colorado.edu";
    public final static int NIST_SERVER_PORT = 13;

    public final static String TAG = "### TAG ###";

    public final static boolean DEBUG = true;

}
