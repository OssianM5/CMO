package com.example.demo

data class ImageItem(val imageResId: Int, val description: String)


