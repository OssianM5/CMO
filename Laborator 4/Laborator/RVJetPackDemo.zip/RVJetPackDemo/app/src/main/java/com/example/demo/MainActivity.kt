package com.example.demo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.demo.ui.theme.RVJetPackDemoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            RVJetPackDemoTheme {
                // Suprafața de bază a aplicației
                Surface {
                    // Generăm lista de date
                    val itemList = remember { generateItemList() }

                    // Afișăm lista
                    ItemList(itemList = itemList, onItemClick = { item ->
                        // Gestionăm click-ul pe element (opțional)
                        println("Element apăsat: ${item.text}")
                    })
                }
            }
        }
    }
}

// Funcție pentru a genera lista de elemente
fun generateItemList(): List<Item> {
    val list = mutableListOf<Item>()
    for (i in 1..50) {
        list.add(Item("Element $i"))
    }
    return list
}





@Composable
fun ListItem(item: Item, onItemClick: (Item) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onItemClick(item) }
            .padding(16.dp)
    ) {
        Text(
            text = item.text,
            fontSize = 18.sp
        )
    }
}


@Composable
fun ItemList(itemList: List<Item>, onItemClick: (Item) -> Unit) {
    LazyColumn {
        items(itemList) { item ->
            ListItem(item = item, onItemClick = onItemClick)
        }
    }
}