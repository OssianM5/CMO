package com.example.demo

data class Item(val text: String)
